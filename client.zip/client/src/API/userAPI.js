import axios from "axios"

export const registerUser = async (userData)=>{
  const response = await axios.post("http://localhost:4000/user",userData)
}

export const logUser = async(email,password)=>{
  const response = await  axios.get(`http://localhost:4000/user/${email}/${password}`)
  return response
}


export const getPage =  async()=>{
  const response = await axios.get("http://localhost:4000/home")
  return response
}

export const getUsuario =  async(id)=>{
  const response = await axios.get(`http://localhost:4000/user/${id}`)
  return response
}

export const postBlog = async (blog)=>{
  const response = await axios.post("http://localhost:4000/blog",blog)
}


export const getBlog = async (id)=>{
  const response = await axios.get(`http://localhost:4000/blog/${id}`)
  return response
}

export const getBlogs = async ()=>{
  const response = await axios.get("http://localhost:4000/blog")
  return response
}

export const eraseBlog = async (id)=>{
  const response = await axios.delete(`http://localhost:4000/blog/${id}`)
}

export const updateUser = async (user,id)=>{
  const response = await axios.put(`http://localhost:4000/user/${id}`,user)
}




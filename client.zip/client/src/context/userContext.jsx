import React, { createContext, useContext,useState} from "react";
import { registerUser, logUser, getPage,getUsuario, postBlog, getBlog,getBlogs, eraseBlog, updateUser } from "../API/userAPI.js";

const usuarioContext = createContext();

//Este metodo sera donde nosotros podremos exportar nuestros metodos que nos conecta a la api
export const useUser = () => {
  try {
    const context = useContext(usuarioContext);
    return context;
  } catch (error) {
    console.error(error);
  }
  
};

function UserContext(props) {
  //Aqui colocaremos los metodos que estan conectados a la api
  const [user,setUser] = useState()
  const [tasks,setTasks]=  useState([])

  async function CreateUser(userData) {
    try {
      const response = await registerUser(userData);
      console.log(response);
    } catch (error) {
      console.error(error);
    }
  }

  async function LoginUser(email,password){
    try{
      const data = await logUser(email,password)
      return data.data
    }catch(error){
      console.error(error)
    }
  }

  async function getHome(){
    try{
        const data = await getPage()
        setTasks(data.data)
        return data.data
    }catch(error){
      console.log(error)
    }
  }

  async function getUser(id){
    try{
      const data = await getUsuario(id)
      return data.data
    }catch(error){
      console.log(error)
    }
  }

  async function createBlog(blog){
    try{
        const res = await postBlog(blog)
        console.log(res)
    }catch(error){
      console.error(error)
    }
  }

  async function viewBlog(id){
    try{
        const data = await getBlog(id)
        return data.data
    }catch(error){
      console.error(error)
    }
  }


  async function listBlogs(){
    try{
        const data = await getBlogs()
        return data.data
    }catch(error){
      console.error(error)
    }
  }

  async function deleteBlog(id){
    try{
        const response = await eraseBlog(id)
        setTasks(tasks.filter(tasks =  tasks.id !== id
          ))
    }catch(error){
      console.error(error)
    }
  }

  async function upUser (user,id){
      try{
        const response = await updateUser(user,id)
        console.log(response)
      }
      catch(error){
        console.error(error)
      }
  }

  //Aqui pondremos los metodos que creamos para asi llamarlos en otros componentes
  return (
    <usuarioContext.Provider
      value={{
        CreateUser,
        LoginUser,
        getHome,
        user,
        setUser,
        getUser,
        createBlog,
        viewBlog,
        listBlogs,
        deleteBlog,
        upUser
      }}
    >
      {props.children}
    </usuarioContext.Provider>
  );
}

export default UserContext;

import { Routes, Route, Form } from "react-router-dom"
import './App.css';
import Login from "./components/login.jsx"
import Register from "./components/register";
import UserContext from './context/userContext';
import Home from "./components/home";
import FormBlog from "./components/FormBlog";
import Blog from "./components/blog";
import NotFound from "./components/NotFound";
function App() {
  const userID = localStorage.getItem("isLoggedIn");
  return (
    <div>
          <UserContext>
    <Routes>
      <Route path="/" element={<Login/>}>
     
      </Route>
      <Route path="/register" element={<Register/>}></Route>
      <Route path="/home" element={<Home></Home>}></Route>
      <Route path="/creatingBlog" element={<FormBlog></FormBlog>}></Route>
      <Route path="/reviewBlog/:id" element={<Blog></Blog>}></Route>
      <Route path="/updateUser/:id" element={<Register/>}></Route>
      <Route path="*" element={<NotFound></NotFound>}></Route>
    </Routes>
    </UserContext>
    </div>
  );
}

export default App;

import "./style.css"
import { useEffect,useState } from "react";
import { useNavigate,Redirect } from "react-router-dom";
import { Link } from "react-router-dom";
import { FaHireAHelper } from "react-icons/fa6";
function NavBar() {
  const userID = localStorage.getItem('isLoggedIn');
  const [estado,setEstado] = useState(false)
  const navigate = useNavigate()

  useEffect(()=>{
    function validar() {
      
      if (userID) {
        console.log(userID)
      }else{
        navigate('/');
      }
    }
  
    validar()
  },[])

  return (
    <div>
      <nav className="navbar navbar-dark bg-primary">
        <div className="container-fluid">
          <Link to="/home"><h1 className="text-white mx-2"><FaHireAHelper></FaHireAHelper></h1> </Link>
          <button
            className="btn btn-outline-success boton"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarScroll"
            aria-controls="navbarScroll"
            aria-expanded="false"
            aria-label="Toggle navigation"
            onClick={()=>{
              console.log(userID)
              if(userID){
                localStorage.removeItem('isLoggedIn')
                navigate("/")
              }
            }}
          >
          <h5>Log Out</h5>
          </button>
        </div>
      </nav>
    </div>
  );
}

export default NavBar;

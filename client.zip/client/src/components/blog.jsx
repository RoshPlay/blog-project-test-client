import React from "react";
import { useUser } from "../context/userContext";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import NavBar from "./NavBar";
function Blog() {
  const { viewBlog, getUser, deleteBlog } = useUser();
  const [datos, setDatos] = useState([]);
  const [user, setUser] = useState({});
  const userID = localStorage.getItem("isLoggedIn");
  const params = useParams();
  const navigate = useNavigate()

  useEffect(() => {
    const getUsuario = async () => {
      const resp = await getUser(userID);

      setUser(resp);
    };
    const getBlog = async () => {
      if (params.id) {
        const data = await viewBlog(params.id);
        console.log(data);
        setDatos(data);
      }
    };

    getBlog();
    getUsuario();
  }, []);
  return (
    <div>
      <NavBar/>
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-12">
            <div className="card">
              <div className="card-body">
                {datos.map((dato) => {
                  return (
                    <div key={dato.id}>
                      <h5 className="card-title">{dato.title}</h5>
                      <small className="card-text">
                        {" "}
                        {dato.author_id == user.id ? user.name : ""}
                      </small>
                      <p className="card-text">{dato.content}</p>

                      <p className="card-text">Categoría: {dato.category}</p>
                      {dato.author_id == userID ? <button className="btn btn-danger" onClick={async()=>{
                  deleteBlog(params.id)  
                  navigate("/home")
                }}>
                  Delete Blog
                </button> : ""}
                    </div>
                    
                  );
                })}

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Blog;

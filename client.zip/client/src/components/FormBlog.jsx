import React from 'react'
import { Formik, Form, Field } from 'formik';
import { useUser } from '../context/userContext';
import { useEffect,useState } from 'react';
import { useNavigate } from "react-router-dom"
import NavBar from './NavBar';

function FormBlog() {
  const {createBlog,getUser} = useUser()
  const navigate =  useNavigate()
  const userID = localStorage.getItem('isLoggedIn');

  useEffect(()=>{
    const obtenUser =  async()=>{
      const data = await getUser(userID)
      
    }
    obtenUser()
  },[])

  return (
    <div>
      <NavBar/>
 <div className="container mt-4">
      <div className="row justify-content-center">
        <div className="col-md-12">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Nuevo Blog</h5>
              <Formik
                initialValues={{
                  title: '',
                  content: '',
                  author_id: userID,
                  category: '',
                  image_url: '',
                }}
                onSubmit={async (values,action)=>{
                  try{
                      console.log(values)
                      const response =  await createBlog(values)
                      navigate('/home')
                      console.log(response)
                  }catch(error){
                    console.error(error)
                  }
                }}
              >
                {({ isSubmitting,handleChange, handleSubmit, values }) => (
                  <Form onSubmit={handleSubmit}>
                    <div className="mb-3">
                      <input type="text" name="title" placeholder='Blog Title' className='form-control' onChange={handleChange} values={values.title} required/>
                    </div>
                    <div className="mb-3">
                      <textarea  name="content" placeholder='Blog Content'  rows="10" cols="50" className='form-control' onChange={handleChange}  values={values.content} required></textarea>
                    </div>
                    <div className="mb-3">
                      <select className="form-select"  name="category" onChange={handleChange} required>
                        <option selected disabled value="">Choose your category</option>
                        <option value="Technology">Technology</option>
                        <option value="Showbiz">Showbiz</option>
                        <option value="Sciences">Sciences</option>
                        <option value="Policy">Policy</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <button
                      type="submit"
                      className="btn btn-primary"
                      disabled={isSubmitting}
                    >
                      Publicar
                    </button>
                  </Form>
                )}
              </Formik>
            </div>
          </div>
        </div>
      </div>
    </div>  
    </div>
  )
}

export default FormBlog

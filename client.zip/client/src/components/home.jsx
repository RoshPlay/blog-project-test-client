import { useUser } from "../context/userContext";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import NavBar from "./NavBar";

function Home() {
  const [part, setPart] = useState([]);
  const [myUser, setUser] = useState({});
  const [blog, setBlog] = useState([]);
  const { getHome, user, getUser, listBlogs } = useUser();
  const navigate = useNavigate();
  //Es mejor usar localStorage
  const userID = localStorage.getItem("isLoggedIn");

  useEffect(() => {
    const testData = async () => {
      const data = await getHome();
      const dataUser = await getUser(userID);
      const dataBlogs = await listBlogs();

      setUser(dataUser);
      setPart(data);
      setBlog(dataBlogs);
    };

    testData();
  }, []);

  return (
    <>
      <NavBar></NavBar>
      <div className="container mt-4">
        <div className="row justify-content-around ">
          <div className="col-md-3 ">
            <div className="card ">
              <div className="card-header text-white bg-dark">
                <h5 className="text-center">User Data</h5>
              </div>
              <div className="card-body">
                <div className="d-flex  text-end gap-2">
                  <h6 className="fw-bold">Name: </h6>
                  <h6>{myUser.name}</h6>
                </div>
                <div className="d-flex text-end gap-2">
                  <h6 className="fw-bold">Email: </h6>
                  <h6>{myUser.email}</h6>
                </div>
                <div className="d-flex justify-content-center mt-2 mb-2">
                  <button
                    className="btn btn-primary"
                    onClick={() => {
                      navigate("/creatingBlog");
                    }}
                  >
                    Create new blog
                  </button>
                </div>
                <div className="d-flex justify-content-center mt-2 mb-2">
                  <button
                    className="btn btn-success"
                    onClick={() => {
                      navigate(`/updateUser/${userID}`);
                    }}
                  >
                    Modify
                  </button>
                </div>
                <div>
                  <h6>My blog list</h6>
                  {blog.map((bl) => {
                    return (
                      <>
                        <Link
                          to={`/reviewBlog/${bl.id}`}
                          className="d-block mt-2"
                          key={bl.id}
                        >
                          {bl.author_id == userID ? bl.title : ""}
                        </Link>
                      </>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          <div className="col-md-8 ">
            <div className="card">
              <div className="card-header bg-primary text-white">
                MyBlog Wall
              </div>
              <div className="card-body justify-content-center align-items-center text-center">
                {part.map((post) => (
                  <div key={post.id} className="mb-4">
                    <Link to={`/reviewBlog/${post.blog}`} className="d-block">
                      <h2>{post.title}</h2>
                    </Link>
                    <h5>{post.name}</h5>
                    <small className="text-muted">
                      Created on {post.create_at}
                    </small>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Home;

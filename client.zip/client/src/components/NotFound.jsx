import React from 'react'

function NotFound() {
  return (
    <div className='d-flex text-white justify-content-center align-items-center container'>
      <h1 className='lh-lg fw-bold'>PAGE NOT FOUND</h1>
    </div>
  )
}

export default NotFound

import { Form, Formik } from "formik";
import { useUser } from "../context/userContext";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { Link } from "react-router-dom";
import logoImage from '../images/Logo1.png';
import { FaHireAHelper } from "react-icons/fa6";

function Login() {
  const { LoginUser, setUser } = useUser();
  const navigate = useNavigate();
  const [validar, setValidar] = useState(false);
  
  return (
    <div className="full-page d-flex align-items-center justify-content-center"> 
      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card text-white bg-dark">
              <Formik
                enableReinitialize={true}
                initialValues={{
                  email: "",
                  password: "",
                }}
                onSubmit={async (values, action) => {
                  try {
                    const res = await LoginUser(values.email, values.password);
                    console.log(res)
                    if (res.length != 0) {
                      setUser(res[0].id)
                      localStorage.setItem('isLoggedIn', res[0].id);
                      navigate("/home");
                    } else {
                      setValidar(true);
                    }
                  } catch (error) {
                    console.error(error);
                  }
                }}
              >
                {({ handleChange, handleSubmit, values }) => (
                  <Form onSubmit={handleSubmit}>
                    <div className="card-header bg-primary text-white text-center">
                   <h3><FaHireAHelper></FaHireAHelper></h3> 
                      LOGIN

                    </div>
                    <div className="card-body">
                      <div className="mb-3">
                      <label htmlFor="username" className="form-label">
                        User Email
                      </label>
                      <input
                        type="text"
                        className="form-control"
                        required
                        placeholder="User Email"
                        value={values.email}
                        onChange={handleChange("email")}
                      />
                      </div>
                      <div className="mb-3">
                            <label htmlFor="password" className="form-label">
                        Password
                      </label>
                      <input
                        type="password"
                        className="form-control"
                        required
                        placeholder="Type your password"
                        value={values.password}
                        onChange={handleChange("password")}
                      />
                      </div>
                  
                      <div className="card-body d-flex justify-content-center align-items-center">
                      <button type="submit" className="btn btn-primary">
                        Sign in
                      </button>
                      </div>
                      <div className=" d-flex justify-content-center align-items-center">
                      <Link to="/register">Create an account</Link>
                        </div>
                        <h1 className="d-block text-center" >{validar ? "Invalid password or email" : ""}</h1>                     
                    </div>
                  </Form>
                )}
              </Formik>
             
            </div>
          </div>
        </div>
      </div>
      </div>
  );
}

export default Login;

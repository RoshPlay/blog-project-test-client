import { Form, Formik } from "formik";
import { useUser } from "../context/userContext";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import NavBar from "./NavBar";
import { useParams } from "react-router-dom";

function Register() {
  const { CreateUser, upUser, getUser } = useUser();
  const navigate = useNavigate();
  const userID = localStorage.getItem("isLoggedIn");
  const [usuario, setUsuario] = useState({
    name: "",
    email: "",
    password: "",
    birthdate: ""
  });
  const params = useParams();

  useEffect(() => {
    const getData = async () => {
      const data = await getUser(userID);
      console.log(data);
      setUsuario({
        name: data.name,
        email: data.email,
        password: data.password,
        birthdate: data.birthdate
      });
    };

    getData();
  }, []);

  return (
    <>
      {userID ? <NavBar /> : ""}

      <div className="full-page d-flex align-items-center justify-content-center">
        <div className="container mt-5">
          <div className="row justify-content-center">
            <div className="col-md-6">
              <div className="card text-white bg-dark">
                <Formik
                  enableReinitialize={true}
                  initialValues={usuario}
                  onSubmit={async (values, actions) => {
                    
                    try {
                      if (params.id) {
                        console.log(values);
                        await upUser(values, params.id);
                        navigate("/home");
                      } else {
                        const resp = await CreateUser(values);
                        console.log(resp);
                        navigate("/");
                      }
                      setUsuario({
                        name: "",
                        email: "",
                        password: "",
                        birthdate: "",
                      });
                    } catch (error) {
                      console.log(error);
                    }
                  }}
                >
                  {({ handleChange, handleSubmit, values }) => (
                    <Form onSubmit={handleSubmit}>
                      <div className="card-header bg-primary text-white">
                        User Register
                      </div>
                      <div className="card-body">
                        <label className="form-label">User name:</label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          required
                          value={values.name}
                          onChange={handleChange}
                          className="form-control"
                        />
                        <label className="form-label">Email:</label>
                        <input
                          type="email"
                          name="email"
                          required
                          value={values.email}
                          onChange={handleChange}
                          className="form-control"
                        />
                        <label className="form-label">Password</label>
                        <input
                          type="password"
                          required
                          name="password"
                          value={values.password}
                          onChange={handleChange}
                          className="form-control"
                        />
                        <label className="form-label">BirthDate</label>
                        <input
                          type="date"
                          required
                          name="birthdate"
                          value={values.birthdate}
                          onChange={handleChange}
                          className="form-control"
                          placeholder="Example: YYYY-MM-dd'"
                        />

                        <div className="d-flex align-items-center justify-content-center mt-3">
                          <button type="submit" className="btn btn-primary">
                            Submit
                          </button>
                        </div>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default Register;
